const axios = require('axios');

exports.handler = async (event) => {
    const query = event.queryStringParameters.q || 'technology';
    const API_KEY = '559265ff166941cba2071adbb15937c5';
    const url = `https://newsapi.org/v2/everything?q=${query}&apikey=${API_KEY}`;

    try {
        const response = await axios.get(url);
        return {
            statusCode: 200,
            body: JSON.stringify(response.data),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message }),
        };
    }
};
